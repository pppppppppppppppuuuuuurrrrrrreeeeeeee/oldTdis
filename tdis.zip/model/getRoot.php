<?php

require 'functions.php';

echo getRoot();